package com.spring.start.Spring_Boot_Complete;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootCompleteApplicationTests {

	@Test
	void contextLoads() {
	}

}

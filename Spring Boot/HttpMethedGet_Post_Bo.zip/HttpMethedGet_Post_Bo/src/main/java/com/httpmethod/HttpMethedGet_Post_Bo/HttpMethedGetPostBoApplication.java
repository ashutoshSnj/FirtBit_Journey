package com.httpmethod.HttpMethedGet_Post_Bo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HttpMethedGetPostBoApplication {

	public static void main(String[] args) {
		SpringApplication.run(HttpMethedGetPostBoApplication.class, args);
	}

}

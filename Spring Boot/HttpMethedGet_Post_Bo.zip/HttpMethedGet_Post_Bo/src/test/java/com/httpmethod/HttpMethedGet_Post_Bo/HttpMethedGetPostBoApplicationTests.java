package com.httpmethod.HttpMethedGet_Post_Bo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HttpMethedGetPostBoApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.data_jpa_Star.Data_Jpa_DB_Connectio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataJpaDbConnectioApplicationTests {

	@Test
	void contextLoads() {
	}

}

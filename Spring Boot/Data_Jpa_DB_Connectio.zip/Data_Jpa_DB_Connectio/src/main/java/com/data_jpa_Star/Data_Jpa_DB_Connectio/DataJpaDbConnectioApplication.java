package com.data_jpa_Star.Data_Jpa_DB_Connectio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DataJpaDbConnectioApplication {

	public static void main(String[] args) {
		SpringApplication.run(DataJpaDbConnectioApplication.class, args);
	}

}

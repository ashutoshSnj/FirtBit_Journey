package com.frstboot.springbootfristprojec;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootfristprojecApplicationTests {

	@Test
	void contextLoads() {
	}

}

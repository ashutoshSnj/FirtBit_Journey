package com.frstboot.springbootfristprojec;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootfristprojecApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootfristprojecApplication.class, args);
	}

}

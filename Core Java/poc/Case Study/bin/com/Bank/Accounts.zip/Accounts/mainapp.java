package com.Bank.Accounts;

public class mainapp {

	public static void main(String[] args) {
	    Account[] allaccount = new Account[]{ new Saving_Account()  };
	    
	    
	}

}

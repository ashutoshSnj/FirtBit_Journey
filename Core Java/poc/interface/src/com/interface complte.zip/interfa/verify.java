package com.interfa;

public interface verify {
	public void asss();

}

package com.interfa;

public class Hr extends Employee  implements verify{
	 double allwance;
	 
	public Hr() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Hr(int id, String name, double salary,double al) {
		super(id, name, salary);
		this.allwance=al;
		//  TODO Auto-generated constructor stub
	}
	 public  void prientable() {
		 System.out.println("Hr call");
	 }

	@Override
	public void asss() {
		// TODO Auto-generated method stub
		
	}

	
}

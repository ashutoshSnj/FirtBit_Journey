package com.interfa;

public interface printable {
	public void prientable();

}

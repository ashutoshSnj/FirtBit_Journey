package com.interfa;

public class Traneer implements printable {
	public  void prientable() {
		System.out.println("Traneer call");
		 
	 }

}

package rolebase;

public interface payebal {
     public void pay();
}

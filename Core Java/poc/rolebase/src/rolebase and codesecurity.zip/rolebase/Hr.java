package rolebase;

public class Hr extends Employee{

	 public Hr() {
		// TODO Auto-generated constructor stub
	}
	 
	public Hr(int id, String name, Double salary) {
		super(id, name, salary);
		// TODO Auto-generated constructor stub
	}

	public void pay() {
		System.out.println("hr  call");
		
	}

}

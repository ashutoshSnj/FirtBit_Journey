package rolebase;

public class contracter implements payebal {

	public contracter() {
		// TODO Auto-generated constructor stub
	}
	public void pay() {
		System.out.println("contracter call");
		
	}

}
